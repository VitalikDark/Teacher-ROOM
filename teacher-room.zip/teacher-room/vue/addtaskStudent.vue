Vue.component('addtaskstudent', {
	data() {
		return {
			dataend: '',
			days: '',
			newStudent: {},
			studentIndex: [{
				nameStudentIndex: 'Студент',
				topicStudentIndex: 'Тема роботи',
				days: ''
			}]
		}
	},
	template: `
	<div>
		<input type="text" placeholder="Ім'я" v-model="newStudent.nameStudentIndex" class="empty-inp">
		<input type="text" placeholder="тема" v-model="newStudent.topicStudentIndex" class="empty-inp">
		<input type="date" placeholder="дата закінчення" @change="deadline" v-model="dataend">
		<button @click="addtoList" class="button-green btn">Додати</button>

		<!-- <pre>{{ newStudent }}</pre> -->
		<div id="rezult" v-for="(studentIndexes, index) in studentIndex" :key="index">
			<div class="box">
				<div class="name-student">{{studentIndexes.nameStudentIndex}}</div>
				<div class="topic-student">{{studentIndexes.topicStudentIndex}}</div>
				<div class="days-end"> {{studentIndexes.days}} днів</div>
				<div class="tab" :class="[сolorTag(studentIndexes.days)]"></div>
				<button @click="deleteItem(index)" class="button-red btn">Видалити</button>
			</div>
		</div>
	</div>
	`,
	methods: {
		deadline() {
			const msPerDay = 8.64 * Math.pow(10, 7);
			const abs = Date.parse(this.dataend) - Date.now();
			this.newStudent.days = Math.ceil(abs / msPerDay);
		},
		addtoList() {
			this.studentIndex.push(this.newStudent);
			this.dataend = 0;
			Vue.set(this, 'newStudent', {});
		},
		deleteItem(index) {
            this.studentIndex.splice(index, 1);
        }
	},
	computed: {
		сolorTag() {
			return (days) => {
				switch (true) {
					case days > 60:
					{
						return 'blue'
					}
					case days < 60 && days > 14:
					{
						return 'yellow'
					}
					case days < 14:
					{
						return 'red'
					}
				}
			}
		}
	}
});