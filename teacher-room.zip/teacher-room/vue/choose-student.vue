//add student from list
Vue.component('choose-student', {
data(){
    return {
        groups:[
        {id:1, members:['Слободянюк', 'Байнак', 'Шелепко', 'Крента', 'Мак']},
        {id:2, members:['Ореховський', 'Домінська', 'Тарасов']},
        {id:3, members:['Янукович', 'Порошенко', 'Соломінський']},
        ],
        isShow: false,
        listStudent:[]
}},
methods: {
        showGroup(i){
            return this.groups[i].itemstudent = !this.groups[i].itemstudent;
        },
        addUser(list){
            this.listStudent.push(list);
        },
        deleteItem(index) {
            this.listStudent.splice(index, 1);
        }
    },
    created() {
        this.groups.forEach(element => {
            this.$set(element, 'itemstudent', false)
        });
    },
template: `
    <div>
        <ul v-for="(group,index) in groups" :key="group.id" v-show="isShow">
        <h3 @click="showGroup(index)"> Група - {{group.id}} </h3>
        <li v-for="list in group.members" v-show="group.itemstudent" @click="addUser(list)">
        {{list}}
        </li>
        </ul>
        <button @click="isShow=!isShow" v-show="!isShow" class="button-green btn">Додати студента!</button>
        <ul v-show="isShow">
            <div>Мої студенти: </div>
            <li v-for="(lastName, index) in listStudent">
            {{lastName}}
            <button @click="deleteItem(index)" class="button-red btn">Видалити</button>
            </li>
        </ul>
    </div>
    `
});