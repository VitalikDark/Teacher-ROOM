Vue.component('data-tag', {
	data() {
		return {
			dataend: '',
			days: '',
			isred: true,
			isyellow: true,
			isblue: true
		}
	},
	template: '\
    <div>\
      <input type="date" placeholder="дата закінчення" v-model="dataend">\
      <div> {{days}} днів</div>\
      <div class="tab" :class="`tab ${сolorTag}`"></div>\
    </div>\
    ',
	watch: {
		dataend(){
			this.deadline();
		}
	},
	methods: {
		deadline() {
			const msPerDay = 8.64 * Math.pow(10, 7);
			const abs = Date.parse(this.dataend) - Date.now();
			this.days = Math.ceil(abs/msPerDay);
		}
	},
	computed: {
		сolorTag() {
	        switch(true) {
	            case this.days > 60: {
	              return 'blue'
	            }
	            case this.days < 60 && this.days>14: {
	              return 'yellow'
	            }
	            case this.days < 14: {
	              return 'red'
	            }
	        }
		}
	}
});