// container will edit whan you click
Vue.component('edit-container', {
	data() {
		return {
			value: 'Зауваження: ',
			tempValue: null,
			editing: false
		}
	},
	template: `
	<div>
		<div v-if="!editing">
			<span class='text' @click="enableEditing">{{value}}</span>
		</div>
		<div v-if="editing">
			<input v-model="tempValue" class="input"/>
			<button @click="disableEditing" class="btn button-red"> Відміна </button>
			<button @click="saveEdit" class="btn button-green"> Зберегти! </button>
			<div >{{counter}}</div>
		</div>
	</div>
	`,
	computed: {
		counter() {
			return this.tempValue.length;
		},
	},
	methods: {
		enableEditing: function(){
			this.tempValue = this.value;
			this.editing = true;
		},
		disableEditing: function(){
			this.tempValue = null;
			this.editing = false;
		},
		saveEdit: function(){
			this.value = this.tempValue;
			this.disableEditing();
		}
	}
});