Vue.component('task', {
	data() {
		return {
			tasks: [
				{ id: 1, description: 'Завдання 1', completed: false }
			],
			newTaskText: '',
			newTaskId: 4
		}
	},
	template: `
	<div class="content">
	<h3 class="title">Мій список завдань</h3>
	<hr/>
	<div class="container">
		<h3>Мої задачі</h3>
		<ul class="tasks todo">
			<li class="task" v-for="task in incompleteTasks">
				<div class="field is-grouped">
					<div class="control"><input type="checkbox" v-bind:id="'task-' + task.id" v-model="task.completed" /><label v-bind:for="'task-' + task.id">{{task.description}}</label><span class="button-delete" v-show="task.completed" @click="deleteTask(task.id)">×</span></div>
				</div>
			</li>
			<p class="empty-text" v-if="!incompleteTasks.length">Твої завдання завершені</p>
		</ul>
	</div>
	<div class="container">
		<h3>Виконані завдання</h3>
		<ul class="tasks completed">
			<li class="task" v-for="task in completedTasks">
				<div class="field is-grouped">
					<div class="control"><input type="checkbox" v-bind:id="'task-' + task.id" v-model="task.completed" /><label v-bind:for="'task-' + task.id">{{task.description}}</label><span class="button-delete" v-show="task.completed" @click="deleteTask(task.id)">×</span></div>
				</div>
			</li>
			<p class="empty-text" v-if="!completedTasks.length">Ваш список порожній</p>
		</ul>
	</div>
	<div class="container box">
		<h3>Додати завдання </h3>
		<div class="field has-addons">
			<div class="control is-expanded"><input class="input is-fullwidth" id="task-input" type="text" v-model="newTaskText" @keyup.enter="addTask" /></div>
			<div class="control"><button class="button-blue btn" @click="addTask">Додати!</button></div>
		</div>
	</div>
	</div>
	`,
	methods: {
		addTask() {
			let input = document.querySelector('#task-input');

			if(input.value) {
				this.tasks.push({
					id: this.newTaskId++,
					description: this.newTaskText,
					completed: false
				});
				this.newTaskText = '';
			}
		},

		deleteTask(id) {
			let taskId = this.tasks.map(task => task.id).indexOf(id)
			this.tasks.splice(taskId, 1)
		}
	},
	computed: {
		completedTasks() {
			return this.tasks.filter(task => task.completed);
		},
		incompleteTasks() {
			return this.tasks.filter(task => !task.completed);
		}
	}
		
});